# import sklearn
# import pandas as pd 

def dummy_function(a:int, b:int):
    return a+b