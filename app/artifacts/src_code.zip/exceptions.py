class DownloadModelError(Exception):
    pass

class LoadModelError(Exception):
    pass