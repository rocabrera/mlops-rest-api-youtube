class DownloadModelError(Exception):
    pass